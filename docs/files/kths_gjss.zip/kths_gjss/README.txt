Song darf nicht nicht über 4:59 sein
Song muss "precipice.ogg" heißen und an dieser Position sein: kths_gjss/assets/minecraft/sounds/records/precipice.ogg